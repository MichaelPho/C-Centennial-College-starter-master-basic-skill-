﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LPho_300980694_A1
{

    class Event
    {
        Distance distance;
        Stoke swimCode;
        public Distance Distance
        {
            set { distance = value; }
            get { return distance; }
        }
        public Stoke SwimCode
        {
            set { swimCode = value; }
            get { return swimCode; }
        }
        public Event(Stoke swimCode, Distance distance)
        {
            SwimCode = swimCode;
            Distance = distance;
        }

        public string GetInfo()
        {
            return $"Code is :{swimCode}\nDistance is :{(int)distance}/meters";
        }
    }
}
