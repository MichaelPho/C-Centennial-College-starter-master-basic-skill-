﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LPho_300980694_A1
{


    class Club
    {
        static int ClubIdNumber = 0;


        int clubNumber;
        string name;
        long telephoneNumber;
        Address address = new Address();



        public int ClubNumber
        {
            private set
            {
                clubNumber = value;
            }
            get
            {
                return clubNumber;
            }
        }

        public string Name
        {
            set
            {
                name = Program.Formating(value);
            }
            get
            {
                return name;
            }
        }

        public Address Address
        {
            set
            {
                address = value;
            }
            get
            {
                return address;
            }
        }
        public long TelephoneNumber
        {
            set
            {
                if (value.ToString().Length != 10)
                {
                    Console.WriteLine("this number is not approriate");
                    telephoneNumber = 0;

                }
                else
                    telephoneNumber = value;
            }
            get
            {
                return telephoneNumber;
            }
        }
        public Club(string name, long telephoneNumber, Address address)
        {

            ClubIdNumber += 1;

            ClubNumber = ClubIdNumber;
            Name = name;

            Address = address;
            TelephoneNumber = telephoneNumber;
        }
        
        public string GetInfo()
        {
            string a = telephoneNumber.ToString();
            char[] b = a.ToCharArray();
            if (TelephoneNumber == 0) return $"CLUB_ID is: {clubNumber}\nBrand name is: {name}\nThis is a: {address.type}\nAddress is: {address.addressLine}, {address.city}, {address.province}, {address.postalCode}\nTelephone number: Please update it!!!";

            return $"CLUB_ID is: {clubNumber}\nBrand name is: {name}\nThis is a: {address.type}\nAddress is: {address.addressLine}, {address.city}, {address.province}, {address.postalCode}\nTelephone number: ({b[0]}{b[1]}{b[2]}) {b[3]}{b[4]}{b[5]} {b[6]}{b[7]}{b[8]}{b[9]}";
        }

    }
}

