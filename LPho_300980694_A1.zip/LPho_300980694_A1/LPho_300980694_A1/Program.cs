﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace LPho_300980694_A1
{

    public enum Stoke
    {
        butterfly = 1, backstroke, breaststroke, freestyle,
        individualmedley
    };
    public enum Distance { fifty = 50, hundred = 100, twohundred = 200, fourhundred = 400, eighthundred = 800, fifteenhundred = 1500 };
    public enum Course { SCM, SCY, LCM };
    public struct Address
    {
        public string addressLine;
        public string city;
        public string province;
        public string postalCode;
        public HouseType type;
    };



    public enum HouseType : int { House = 1, Apt, Villa };

    class Program
    {

        static void Main(string[] args)
        {
            int width = 120;
            int height = 50;
            Console.SetWindowSize(width, height);
            PartOne();
            PartTwo();
            PartThree();
            PartFour();
            PartFive();
            Console.WriteLine("Thank You HAVE A GOOD DAY!!!!!!\n\n\t\t\t\t\t P/s: Thanh Lam\n      \t\t\t\t\t #300980694");
        }

        static void PartOne()
        {
            Address address = new Address();
            address.addressLine = "938 Progress ave";
            address.city = "Toronto";
            address.postalCode = "M1G3T8";
            address.province = "Ontario";
            address.type = (HouseType)1;

            Address address2 = new Address();
            address2.addressLine = "251 Levina St.";
            address2.city = "California";
            address2.postalCode = "M9Z1U2";
            address2.province = "USA";
            address2.type = (HouseType)2;


            DisplayWithBorder("PAR1 : Club      ");
            Club partOne = new Club("    BKime    club        ", 4379848261, address);
            Club partOne2 = new Club(Formating(" Kings men    "), 6392812261, address2);

            Console.WriteLine(partOne.GetInfo());
            Console.WriteLine("----------------------------------------------------------------------");
            Console.WriteLine(partOne2.GetInfo());
        }
        static void PartTwo()
        {
            Address address = new Address();
            address.addressLine = Formating("224 Markham Road  ");
            address.city = "Toronto";
            address.postalCode = "M2G4P8";
            address.province = "Ontario";
            address.type = (HouseType)3;

            Address address2 = new Address();
            address2.addressLine = Formating("222 Dundas St."); 
            address2.city = "California";
            address2.postalCode = "M416N2";
            address2.province = "USA";
            address2.type = (HouseType)2;

            DateTime birth = new DateTime(1997, 03, 11);
            DateTime birth2 = new DateTime(1990, 05, 16);

            Registrant partTwo = new Registrant("DAvid Nevia", birth, 6423924952, address);
            Registrant partTwo2 = new Registrant("Micahel Pho", birth2, 5238218123, address2);

            DisplayWithBorder("PAR2 : Registrant");
            Console.WriteLine(partTwo.GetInfo());
            Console.WriteLine("----------------------------------------------------------------------");
            Console.WriteLine(Formating(partTwo2.GetInfo()));
        }
        static void PartThree()
        {
            DisplayWithBorder("PAR3 : Swim Meet ");
            DateTime startDay = new DateTime(2017, 03, 11);
            DateTime endDay = new DateTime(2017, 05, 15);
            Swim_Meet partThree = new Swim_Meet(startDay, endDay, "The Western Union", (Course)1);
            Console.WriteLine(partThree.GetInfo());
        }
        static void PartFour()
        {
            DisplayWithBorder("PAR4 : Event     ");
            Distance distance = Distance.fifty;
            Event partFour = new Event((Stoke)2, distance);
            Console.WriteLine(partFour.GetInfo());
        }
        static void PartFive()
        {
            DisplayWithBorder("PAR5 : Swim      ");
            int heat = 3;
            int lane = 4;
            TimeSpan timeswim = new TimeSpan(0, 0, 40, 23, 25);
            Swim partFive = new Swim(timeswim, heat, lane);
            Console.WriteLine(partFive.GetInfo());
        }

        static public bool CheckNum(string input)
        {

            int test;
            if (int.TryParse(input, out test))
            {
                if (int.Parse(input) < 0)
                {
                    return false;
                }
                return true;
            }
            return false;
        }

        static public string Formating(string text)
        {
            return UppercaseFirstEach(Regex.Replace(text, " {2,}", " ").Trim());
        }

        static public string UppercaseFirstEach(string s)
        {

            char[] a = s.ToLower().ToCharArray();

            for (int i = 0; i < a.Length; i++)
            {
                if (i == 0 || a[i - 1] == ' ')
                    a[i] = char.ToUpper(a[i]);
            }

            return new string(a);
        }
        static public int Get8Digits(ref List<int> array)
        {
            Random rnd = new Random();

            int lowLimit = 10000000;

            int highLimit = 100000000;
            int temp = rnd.Next(lowLimit, highLimit);
            if (array == null)
            {
                array.Add(temp);
            }
            else if (array != null)
            {
                while (array.Contains(temp))
                {
                    temp = rnd.Next(lowLimit, highLimit);
                }
                array.Add(temp);
            }
            return temp;
        }
        static public int Get4Digits(ref List<int> array)
        {
            Random rnd = new Random();

            int temp = rnd.Next(1000, 10000);
            if (array == null)
            {
                array.Add(temp);
            }
            else if (array != null)
            {
                while (array.Contains(temp))
                {
                    temp = rnd.Next(1000, 10000);
                }
                array.Add(temp);
            }
            return temp;
        }
        static public string Get4Digits_4Character(ref List<string> array)
        {
            Random rnd = new Random();
            var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            var stringChars = new char[3];
            for (int i = 0; i < stringChars.Length; i++)
            {
                stringChars[i] = chars[rnd.Next(chars.Length)];
            }
            string temp = stringChars + rnd.Next(1000, 10000).ToString();
            if (array == null)
            {
                array.Add(temp);
            }
            else if (array != null)
            {
                while (array.Contains(temp))
                {
                    temp = stringChars + rnd.Next(1000, 10000).ToString();
                }
                array.Add(temp);
            }
            return temp;
        }
        static void DisplayWithBorder(string input)
        {

            Console.WriteLine("======================================================================");
            Console.WriteLine("=\t\t\t{0}\t\t\t     {1}", input, "=");
            Console.WriteLine("=                                                                    =");
            Console.WriteLine("=                                                                    =");
            Console.WriteLine("======================================================================");
            Console.WriteLine("----------------------------------------------------------------------");
        }
        static void Display(ref int choice)
        {
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Green;


            Console.WriteLine("\t\t*****ASSGINMENT 1 (Centennial College X Programming 2)*****");
            Console.WriteLine();
            Console.WriteLine("  |||             ||| ========  ||	    ========  ==========   ||||||     ||||||  ========");
            Console.WriteLine("   |||    ||||   |||  ===       ||	    ==	      ==      ==   ||| |||   ||| |||  ===");
            Console.WriteLine("    |||  |||||| |||   =======   ||	    ==        ==      ==   |||  ||| |||  |||  =======");
            Console.WriteLine("     ||||||  |||||    ===       ||	    ==        ==      ==   |||   |||||   |||  ===");
            Console.WriteLine("      ||||    |||     ========  ||======    ========  ==========   |||    |||    |||  ========");
            Console.WriteLine(" --------------------------------------------------------------------------------------------");
            Console.WriteLine("======================================================================");
            Console.WriteLine("=             !!!!    ASSIGNMENT 1: CLASS    !!!!                    =");
            Console.WriteLine("=                       -------------                                =");
            Console.WriteLine("=                 -> 1. Part 1                                       =");
            Console.WriteLine("=                 -> 2. Part 2                                       =");
            Console.WriteLine("=                 -> 3. Part 3                                       =");
            Console.WriteLine("=                 -> 4. Part 4                                       =");
            Console.WriteLine("=                 -> 5. Part 5                                       =");
            Console.WriteLine("=                 -> 6. Exit!!!                                      =");
            Console.WriteLine("=                                                                    =");
            Console.WriteLine("======================================================================");
            Console.WriteLine("\t\tPlease enter your choice");
            Console.Write("\t\t    choice:");

            bool checkNum = false;
            while (checkNum == false)
            {
                checkNum = int.TryParse(Console.ReadLine(), out choice);
                if (choice <= 0 || choice > 8)
                {
                    Console.WriteLine("\t\tPlease try again");
                    Console.WriteLine("----------- Press any key to continue   ----------- ");

                    checkNum = false;
                    Console.Write("\t\t    choice:");
                }

            }

        }

    }
}

