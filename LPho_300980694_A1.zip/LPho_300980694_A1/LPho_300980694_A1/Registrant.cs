﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LPho_300980694_A1
{
    class Registrant
    {
        static int RegIdNumber = 0;
        int regNumber;
        string name;
        DateTime dateOfBirth;
        long telephoneNumber;
        Address address = new Address();
        public int RegNumber
        {
            private set
            {
                regNumber = value;
            }
            get
            {
                return regNumber;
            }
        }
        public string Name
        {
            set
            {
                Program.Formating(value);
                name = value;
            }
            get
            {
                return name;
            }
        }
        public DateTime DateOfBirth
        {
            set { dateOfBirth = value; }
            get { return dateOfBirth; }
        }
        public Address RegAddress
        {
            set
            { address = value; }
            get
            { return address; }
        }


        public long TelephoneNumber
        {
            set
            {
                if (value.ToString().Length != 10)
                {
                    Console.WriteLine("this number is not approriate");
                    telephoneNumber = 0;
                }
                else
                    telephoneNumber = value;

            }
            get
            {
                return telephoneNumber;
            }
        }
        public Registrant(string name, DateTime dateOfBirth, long telephoneNumber, Address address)
        {
            RegIdNumber += 1;
            RegNumber = RegIdNumber;
            Name = name;

            if (dateOfBirth >= DateTime.Now)
            {
                Console.WriteLine("this is not approriate number, please try again");
                DateOfBirth = DateTime.Now;
            }
            else
                DateOfBirth = dateOfBirth;
            TelephoneNumber = telephoneNumber;
            RegAddress = address;
        }



        public string GetInfo()
        {
            string a = TelephoneNumber.ToString();
            char[] b = a.ToCharArray();
            if (dateOfBirth == DateTime.Now && TelephoneNumber != 0)
                return $"Registrant ID is :{RegNumber}\nname is: {Name}\nDay of birth is: NOT AVAILABLE ,Please update it!!!\nThis is a: {RegAddress.type}\nAddress is: {RegAddress.addressLine}, {RegAddress.city}, {RegAddress.province}, {RegAddress.postalCode}\nTelephone number: ({b[0]}{b[1]}{b[2]}) {b[3]}{b[4]}{b[5]} {b[6]}{b[7]}{b[8]}{b[9]}";
            else if (TelephoneNumber == 0)
                return $"Registrant ID is :{RegNumber}\nname is: {Name}\nDay of birth is: NOT AVAILABLE ,Please update it!!!\nThis is a: {RegAddress.type}\nAddress is: {RegAddress.addressLine}, {RegAddress.city}, {RegAddress.province}, {RegAddress.postalCode}\nTelephone number: please update it";

            else
                return $"Registrant ID is :{RegNumber}\nname is: {Name}\nDay of birth is:{DateOfBirth.ToString("dd/MM/yyyy")}\nThis is a: {RegAddress.type}\nAddress is: {RegAddress.addressLine}, {RegAddress.city}, {RegAddress.province}, {RegAddress.postalCode}\nTelephone number: ({b[0]}{b[1]}{b[2]}) {b[3]}{b[4]}{b[5]} {b[6]}{b[7]}{b[8]}{b[9]}";
        }
    }
}
