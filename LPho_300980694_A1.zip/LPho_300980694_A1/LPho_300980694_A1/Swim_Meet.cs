﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LPho_300980694_A1
{

    class Swim_Meet
    {
        DateTime startDay;
        DateTime endDay;
        string nameOfMeeting;
        Course poolType;
        public string NameOfMeeting
        {
            set
            {
                nameOfMeeting = Program.Formating(value);
            }
            get
            {
                return nameOfMeeting;
            }
        }
        public DateTime StartDay
        {
            set
            {
                if (value > EndDay)
                {
                    Console.WriteLine("date is not approriate!!! please try again");
                }
                else
                    startDay = value;
            }
            get { return startDay; }
        }
        public DateTime EndDay
        {
            set
            {
                if (value < StartDay)
                {
                    Console.WriteLine("date is not approriate!!! please try again");
                }
                else
                    endDay = value;
            }

            get { return endDay; }
        }
        public Course PoolType
        {
            private set { poolType = value; }
            get { return poolType; }
        }

        public Swim_Meet(DateTime startDay, DateTime endDay, string nameOfMeeting, Course poolType)
        {
            EndDay = endDay;
            StartDay = startDay;
            NameOfMeeting = nameOfMeeting;
            PoolType = poolType;
        }
        public Swim_Meet() : this(DateTime.Now, DateTime.Now, "", (Course)1)
        {
        }
        public string GetInfo()
        {
            return $"Name of Meeting is: {nameOfMeeting}\nStart on: {startDay.ToString("MM/dd/yyyy")}\nEnd on: {endDay.ToString("MM/dd/yyy")}\nCourse of Meeting is: {poolType}";
        }
    }
}
