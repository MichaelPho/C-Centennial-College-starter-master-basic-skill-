﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwimModel
{
    [Serializable]
    public class SwimMeet
    {
        Event[] eventsOfSwimMeet = new Event[50];
        const int eventLimit = 50;
        int eventAmount=0;
        int noOfLane;
        DateTime startDate;
        DateTime endDate;
        string nameOfMeeting;
        PoolType poolType=0;
        public int EventAmount
        {
            get { return eventAmount; }
        }
        public Event[] EventOfSwimMeet { get { return eventsOfSwimMeet; } }
        public int NoOfLane
        {
            set { noOfLane = value; }
            get { return noOfLane; }
        }
        public string Name
        {
            set
            {
                nameOfMeeting =value;
            }
            get
            {
                return nameOfMeeting;
            }
        }
        public DateTime StartDate
        {
            set
            {
                
                    startDate = value;
            }
            get { return startDate; }
        }
        public DateTime EndDate
        {
            set
            {
                    endDate = value;
            }

            get { return endDate; }
        }
        public PoolType PoolType
        {
            set { if ((int)value > 0 && (int)value < 4) Console.WriteLine("This already assign, cant be change"); else poolType = value; }
            get { return poolType; }
        }

        public SwimMeet(string nameOfMeeting, DateTime startDay, DateTime endDay, PoolType poolType, int noOfLane)
        {
            EndDate = endDay;
            StartDate = startDay;
            Name = nameOfMeeting;
            
            PoolType = poolType;
            NoOfLane = noOfLane;
        }
        public SwimMeet() {
            poolType = 0;
             noOfLane = 8;
            this.startDate = new DateTime(0001, 01, 01);
            this.endDate = new DateTime(0001, 01, 01);
        }
        public override string ToString()
        {
            string eventInfo= "";
            string swimInfo = "";
            for (int i = 0; i < EventOfSwimMeet.Length; i++)
            {
                if (EventOfSwimMeet[i] != null)
                {
                    string swimmerInfo = "";
                    for (int j = 0; j < EventOfSwimMeet[i].Swimmers.Length; j++)
                    {
                        if (EventOfSwimMeet[i].Swimmers[j] != null)
                        {
                            if (EventOfSwimMeet[i].Info[j] != null)
                            {
                                swimInfo = "\tHeat is: " + EventOfSwimMeet[i].Info[j].Heat + "Lane is:" + EventOfSwimMeet[i].Info[j].Lane;
                                if (EventOfSwimMeet[i].Info[j].SwimTime.ToString() == "00:00:00")
                                {
                                    swimInfo = swimInfo + "  So seed : no time added";
                                }
                                else
                                {
                                swimInfo = swimInfo + "  time: " + EventOfSwimMeet[i].Info[j].SwimTime.ToString("mm':'ss':'ff");
                                }
                                swimmerInfo += "\n\t" + EventOfSwimMeet[i].Swimmers[j].Name + "\t" + swimInfo;
                            }
                            else
                            {
                                swimInfo = "no swim/";
                                swimInfo = swimInfo + "  So seed : no time added";
                                swimmerInfo += "\n\t" + EventOfSwimMeet[i].Swimmers[j].Name + "\t" + swimInfo;
                            }
                         }
                    }
                    eventInfo = eventInfo + "\n\t" + EventOfSwimMeet[i].Distance + " " + EventOfSwimMeet[i].Stroke + "\n\tSwimmers:"
                            + swimmerInfo;
                }
            }
            return $"Sweem meet name: {Name}\nFrom-to: {StartDate.ToString("yyyy-MM-dd")} to {EndDate.ToString("yyyy-MM-dd")}\n" +
               $"Pool type: {PoolType}\nNo lanes: {NoOfLane}\nEvents:\n\t{eventInfo}";

        }

        public void Seed()
        {

            int @noOfHeat = 1;
            int @noOfLane = 1;
            for (int i = 0; i < EventOfSwimMeet.Length; i++)
                if (EventOfSwimMeet[i] != null)
                {
                    @noOfHeat = 1;
                    @noOfLane = 1;
                    for (int j = 0; j < EventOfSwimMeet[i].Swimmers.Length; j++)
                    {
                        if (EventOfSwimMeet[i].Swimmers[j] != null)
                            EventOfSwimMeet[i].Seed(EventOfSwimMeet[i].Swimmers[j].RegNumber, @noOfHeat, @noOfLane++);
                        if (noOfLane > NoOfLane)
                        {
                            @noOfLane = 1;
                            @noOfHeat++;
                        }
                    }
                }
            
        }

        public void AddEvent(Event @event)
        {
            
            try
            {
                for (int i = 0; i <= eventAmount; i++)
                {
                    if (EventOfSwimMeet[i] == null)
                    
                    {
                        @event.SwimMeet = this;
                        this.eventsOfSwimMeet[this.eventAmount++] = @event;
                        break;
                    }
                }
                
            }
            catch (IndexOutOfRangeException e)
            {
                throw e;
                
            }
            catch (Exception ex) {
                throw ex;
            }
        }






    }
}

