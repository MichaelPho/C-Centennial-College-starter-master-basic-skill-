﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace SwimModel
{
    public class SwimmersManager: ISwimmersRepository
    {
        int numberOfSwimmers = 0;
        public int Number { get { return numberOfSwimmers; }
        }
        ClubsManager clubMngr;
        Swimmer[] swimmers = new Swimmer[100];
        public Swimmer[] Swimmers { get { return swimmers; } }
        List<int> numCheck = new List<int>();
        public SwimmersManager(ClubsManager clbMngr)
        {
            clubMngr = clbMngr;
        }
        public void Add(Swimmer swimmer)
        {
            bool check = false;

            try
            {
                for (int i = 0; i <= numberOfSwimmers; i++)
                {
                    if (swimmers[i] != null)
                    {
                        if (swimmers[i].RegNumber == swimmer.RegNumber && swimmers[i] != null)
                        {
                            Console.WriteLine("already added in this club");
                            break;
                        }

                    }
                    else
                    {
                        swimmers[i] = swimmer;
                        check = true;
                        numCheck.Add(swimmer.RegNumber);
                        break;
                    }
                }
                if (check) this.numberOfSwimmers++;
            }
            catch (IndexOutOfRangeException)
            {
                throw new Exception("over range");
            }
            catch (Exception e2)
            {
                throw e2;
            }

        }
        public Swimmer GetByRegNum(int swimmerNumber)
        {

            for (int i = 0; i < numberOfSwimmers; i++)
            {
                if (swimmers[i].RegNumber == swimmerNumber)
                {
                    return swimmers[i];
                }
                else if (swimmers[i] == null)
                {
                    return null;
                }
            }
            return null;

        }
        public void Load(string fileName, string input)
        {
            char delimeter = Convert.ToChar(input);
            Swimmer[] swimmers = new Swimmer[100];

            string record;
            string[] field;
            FileStream fileIn = null;
            StreamReader reader = null;
            try
            {
                fileIn = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                reader = new StreamReader(fileIn);


                long test;
                int test2;
                DateTime test3;
                record = reader.ReadLine();
                while (record != null)
                {
                    field = record.Split(delimeter);

                    try
                    {
                        if (field[1] == "")
                            throw new Exception($"Invalid swimmer record name is not valid:\n\t {record}");

                        if (!DateTime.TryParse(field[2], out test3))
                            throw new Exception($"Invalid swimmer record D.O.B is not valid:\n\t {record}");
                        if (!int.TryParse(field[0], out test2))
                            throw new Exception($"Invalid swimmer record Reg number is not valid:\n\t {record}");
                        if (!long.TryParse(field[7], out test))
                            throw new Exception($"Invalid swimmer record. Phone number wrong format:\n\t {record}");
                         if ( numCheck.Contains(Convert.ToInt32(field[0])))
                            {
                                throw new Exception($"Invalid swimmer record. Swimmer with the registration number already exists: \n\t {record}");
                            }
                       
                        if (field[8] != null)
                        {
                            
                            Add(new Swimmer(Convert.ToInt32(field[0]), field[1], DateTime.Parse(field[2]), new Address(field[3], field[4], field[5], field[6]), long.Parse(field[7])));
                            clubMngr.GetClubByRegNum(Convert.ToInt32(field[8])).AddSwimmer(GetByRegNum(int.Parse(field[0])));
                            
                        }
                        else if (field[8] == "")
                            
                        Add(new Swimmer(Convert.ToInt32(field[0]), field[1], DateTime.Parse(field[2]), new Address(field[3], field[4], field[5], field[6]), long.Parse(field[7])));

                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);

                    }
                    finally
                    {
                        record = reader.ReadLine();
                    }
                    
                }
                 
                

            }
            catch (Exception ex)
            {
                throw ex;

            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
                if (fileIn != null)
                {
                    fileIn.Close();
                }
            }
            Array.Resize(ref swimmers, numberOfSwimmers);

        }
        public void Save(string fileName)
        {
            BinaryFormatter binFormatter = new BinaryFormatter();
            FileStream fileOut = new FileStream(fileName, FileMode.Create, FileAccess.Write);
            try
            {
                binFormatter.Serialize(fileOut, Swimmers);
            }
            catch (Exception e)
            {

                throw e;
            }
            finally
            {
                if (fileOut != null)
                {
                    fileOut.Close();
                }

            }
        }

        public void LoadSwimmers(string fileName)
        {

            BinaryFormatter binaryFormatter = null;
            FileStream fileIn = null;

            try
            {
                binaryFormatter = new BinaryFormatter();
                fileIn = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                try
                {
                    swimmers = (Swimmer[])binaryFormatter.Deserialize(fileIn);
                }
                catch (ArgumentOutOfRangeException e)
                {
                    throw new Exception("overange\n" + e.Message);

                }
                foreach (var swimmers in swimmers)
                {
                    if (swimmers != null)
                    {
                        numberOfSwimmers++;
                    }
                }

            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (fileIn != null)
                    fileIn.Close();
            }
        }
        public void Save(string fileName, string _input)
        {

            FileStream fileOut = null;
            StreamWriter writer = null;
            try
            {
                fileOut = new FileStream(fileName, FileMode.Create, FileAccess.Write);
                writer = new StreamWriter(fileOut);
                for (int i = 0; i <= Number; i++)
                {
                    if (swimmers[i] != null)
                        writer.WriteLine($"{swimmers[i].RegNumber}{_input}{Swimmers[i].Name}{_input}{Swimmers[i].Address.AddressLine}{_input}{swimmers[i].Address.City}{_input}{swimmers[i].Address.Province}{_input}{swimmers[i].Address.PostalCode}{_input}{swimmers[i].PhoneNumber}");

                }
            }
            catch (Exception ex)
            {
                throw ex;

            }
            finally
            {
                if (fileOut != null)
                {
                    writer.Close();
                }
                if (fileOut != null)
                {
                    fileOut.Close();
                }
            }
            if (writer != null)
            {
                writer.Close();
            }
            if (fileOut != null)
            {
                fileOut.Close();
            }

        }

    }
}
