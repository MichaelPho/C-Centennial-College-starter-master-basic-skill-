﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwimModel
{
    [Serializable]
    public class Registrant
    {

        Club club;
        const int eventLimit=50;
        public static int RegIdNumber = 0;
        int regNumber;
        string name;
        DateTime dateOfBirth;
        long telephoneNumber;
        Address address = new Address();
       
        

        public Club Club
        {
            get { return club; }
            set
            {
                if ((club != null))
                {
                    Console.WriteLine($"{this.name} already assigned to {Club.Name} club");
                }
                else
                {
                    club = value;
                    club.Swimmers[club.SwimmerAmount++] = this;
                }
            }
        }

        public int RegNumber
        {
            
            get
            {
                return regNumber;
            }
        }
        public string Name
        {
            set
            {

                name = value;
            }
            get
            {
                return name;
            }
        }
        public DateTime DateOfBirth
        {
            set { dateOfBirth = value; }
            get { return dateOfBirth; }
        }
        public Address Address
        {
            set
            { address = value; }
            get
            { return address; }
        }
        
        public long PhoneNumber
        {
            set
            {
                
                    telephoneNumber = value;
            }
            get
            {
                return telephoneNumber;
            }
        }
        public Registrant(string name, DateTime dateOfBirth, Address address, long telephoneNumber):this()
        {
            Name = name;
            if (dateOfBirth >= DateTime.Now)
            {
                DateOfBirth = new DateTime(0001, 1, 1);
            }
            else
                DateOfBirth = dateOfBirth;
            PhoneNumber = telephoneNumber;
            Address = address;
        }
        public Registrant(int regNum,string name, DateTime dateOfBirth, Address address, long telephoneNumber)
        {
            this.regNumber = regNum;
            Name = name;
            if (dateOfBirth >= DateTime.Now)
            {
                DateOfBirth = new DateTime(0001, 1, 1);
            }
            else
                DateOfBirth = dateOfBirth;
            PhoneNumber = telephoneNumber;
            Address = address;
        }


        public Registrant() {
            this.regNumber = ++RegIdNumber;
            Address = new Address("","","","");
            Name = "";
            this.telephoneNumber = 0;
            DateOfBirth = new DateTime(0001,1,1);
        }


        public override string ToString()
        {
           if (Club==null)
                return $"Name: {Name}\nDOB: {DateOfBirth}\nAddress:\n\t{Address.AddressLine}\n\t{Address.City}\n\t{Address.Province}\n\t{Address.PostalCode}\nPhone:{PhoneNumber}\nReg number: {RegNumber}\nClub: not assigned";
            else
                return $"Name: {Name}\nDOB: {DateOfBirth}\nAddress:\n\t{Address.AddressLine}\n\t{Address.City}\n\t{Address.Province}\n\t{Address.PostalCode}\nPhone:{PhoneNumber}\nReg number: {RegNumber}\nClub: {Club.Name}";
        }
    }
}
