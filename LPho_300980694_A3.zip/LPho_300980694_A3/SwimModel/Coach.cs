﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwimModel
{
    public class Coach : Registrant
    {
        string credentials;
        public string Credentials { get { return credentials; } set { credentials = value; } }
        List<Swimmer> swimmers = new List<Swimmer>();
        public List<Swimmer> Swimmers { get { return swimmers; } }
        public Coach(string name, DateTime dateOfBirth, Address address, long telephoneNumber) : base(name, dateOfBirth, address, telephoneNumber)
        {
        }
        public Coach(int regNum,string name, DateTime dateOfBirth, Address address, long telephoneNumber) : base(regNum,name, dateOfBirth, address, telephoneNumber)
        {
        }
        public Coach() : base() { }
        public void AddSwimmer(Swimmer swimmer)
        {
            try
            {
                if (Club == null)
                    throw new Exception("the Coach didnt have assign to club");
                
                    foreach (var _swimmer in swimmers)
                    {
                        if (_swimmer.RegNumber == swimmer.RegNumber)
                            throw new Exception($"Swimmer already Assigned to this coach");
                    }
                
                    swimmer.Coach = this;
                    
                
            }
            catch (IndexOutOfRangeException e)
            {
                { throw e; }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public override string ToString()
        {
            string listname = "";

            foreach (var item in swimmers)
            {
                
                    listname = listname + "\n\t-" + item.Name;
                

            }
            if (Club == null)
                return $"Name: {Name}\n Credit:{credentials} \nDOB: {DateOfBirth}\nAddress:\n\t{Address.AddressLine}\n\t{Address.City}\n\t{Address.Province}\n\t{Address.PostalCode}\nPhone:{PhoneNumber}\nReg number: {RegNumber}\nClub: not assigned\nSwimmer:{listname}";
            else
                return $"Name: {Name}\n Credit:{credentials}\nDOB: {DateOfBirth}\nAddress:\n\t{Address.AddressLine}\n\t{Address.City}\n\t{Address.Province}\n\t{Address.PostalCode}\nPhone:{PhoneNumber}\nReg number: {RegNumber}\nClub: {Club.Name}\nSwimmer:{listname}";
        }
    }
}
