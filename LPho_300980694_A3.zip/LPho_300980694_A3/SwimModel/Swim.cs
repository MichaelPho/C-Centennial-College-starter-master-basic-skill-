﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwimModel
{
    [Serializable]
    public class Swim
    {
        TimeSpan defaultTime = new TimeSpan(0, 0, 0,0);
        int heat;
        int lane;
        TimeSpan swimTime;
        public int Heat
        {
            set { heat = value; }
            get { return heat; }
        }
        public int Lane
        {
            set
            {
                lane = value;
            }
            get { return lane; }
        }
        public TimeSpan SwimTime
        {
            set { swimTime = value; }
            get { return swimTime; }
        }
        public Swim(TimeSpan swimTime, int heat, int lane)
        {

            SwimTime = swimTime;
            Heat = heat;
            Lane = lane;
        }
        public Swim(int heat, int lane)
        {
            
            SwimTime = new TimeSpan(0,0,0);
            Heat = heat;
            Lane = lane;
        }
        public Swim()
        {
            SwimTime = new TimeSpan(0, 0, 0);
            Heat = 0;
            Lane = 0;
        }
        public string GetInfo()
        {
            return $"Time Swimming is:{SwimTime.Minutes}:{SwimTime.Seconds}.{SwimTime.Milliseconds}\nHeat number is :{Heat}\nNumber of Lane is: {Lane}";
        }
    }
}
