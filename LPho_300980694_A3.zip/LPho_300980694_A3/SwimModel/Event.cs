﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwimModel
{
    [Serializable]
    public class Event
    {
        EventDistance distance;
        Stroke stroke;
        SwimMeet swimMeet;
        const int regLimit = 100;
        
        Swimmer[] swimmers = new Swimmer[100];
        int amountOfSwimmer;
        Swim [] info =new Swim[100];
        public Swim [] Info { get { return info; } set { info = value; } }
        public int AmountOfSwimmers { get { return amountOfSwimmer; } }
        
        public SwimMeet SwimMeet { get { return swimMeet; } set { swimMeet = value; } }
        public Swimmer[] Swimmers { get { return swimmers; } }
        public EventDistance Distance
        {
            set { distance = value; }
            get { return distance; }
        }
        public Stroke Stroke
        {
            set { stroke = value; }
            get { return stroke; }
        }
        public Event( EventDistance distance, Stroke stroke)
        {
            Stroke = stroke;
            Distance = distance;
        }
        public Event() {
            Stroke = 0;
            Distance = 0;
        }
        
        public override string ToString()
        {
            return $"Code is :{Stroke}\nDistance is :{(int)Distance}/meters";
        }

        public void EnterSwimmersTime(Registrant swimmer1, string v)
        {
            TimeSpan swimTime= new TimeSpan(0,0,0,0);
            try
            {
                swimTime = TimeSpan.Parse($"00:{v}");
            }
            catch(Exception) {
               throw new Exception("Time input is not correct!!!!");
            }

            bool checking = false;

            for (int i = 0; i < Swimmers.Length; i++)
            {
                if (Swimmers[i] != null)
                {
                    if (Swimmers[i].RegNumber == swimmer1.RegNumber)
                    {
                        Info[i].SwimTime = swimTime;
                        checking = true;
                        swimmers[i].AddAsBestTime(swimMeet.PoolType, distance, stroke, swimTime);
                        


                        break;
                    }
                }
            }
            if (checking == false)
            {
                throw new Exception($"Swimmer {swimmer1.Name} has not entered event");
            }
        }

        public void Seed(int a, int @noOfHeat,int @noOfLane)
        {
            for (int i = 0; i < Swimmers.Length; i++)
            {
                if (Swimmers[i].RegNumber == a)
                {
                    Info[i]= new Swim(@noOfHeat,@noOfLane);
                    break;
                }
            }
        }
        public void AddSwimmer(Registrant swimmer)
        {
            
            if (AmountOfSwimmers >= 0 && AmountOfSwimmers < regLimit)
            {
                if (AmountOfSwimmers == 0)
                {
                    this.swimmers[this.amountOfSwimmer++] = (Swimmer)swimmer;
                    
                }
                else
                {
                    bool check = true;
                    for (int i = 0; i < this.amountOfSwimmer; i++)
                    {
                        if (this.swimmers[i].RegNumber == swimmer.RegNumber)
                            check = false;
                    }
                    if (!check)
                    {
                        throw new Exception($"Swimmer {swimmer.Name},{swimmer.RegNumber} is already entered");
                    }
                    else
                    {
                        
                        this.swimmers[this.amountOfSwimmer++] = (Swimmer)swimmer;
                        
                    }
                }
            }
            else
               throw new Exception("It's over range of the Amount");
        }
    }
}
