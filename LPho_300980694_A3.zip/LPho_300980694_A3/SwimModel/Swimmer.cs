﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwimModel
{
    public class Swimmer : Registrant
    {

        Coach coach=null;

        List<string> eventInfo = new List<string>();
        List<TimeSpan> time = new List<TimeSpan>();
        public Coach Coach
        {
            get { return coach; }
            set
            {
                if (coach != null )
                {
                    throw new Exception($"{base.Name} already assigned to another Coach {value.Name} ");
                }
                if(value.Club.ClubNumber != this.Club.ClubNumber)
                {
                    throw new Exception("Coach and Swimmer are in differnent club");
                }
                if(Club== null)
                {
                    throw new Exception(" Swimmer not in club");
                }
                if (coach==null)
                {
                    coach = value;
                    coach.Swimmers.Add(this);
                }
            }
        }
        public List<string> EventInfo { get { return eventInfo; } set { eventInfo = value; } }

        public Swimmer(string name, DateTime dateOfBirth, Address address, long telephoneNumber) : base(name, dateOfBirth, address, telephoneNumber)
        {
        }
        public Swimmer(int regNum,string name, DateTime dateOfBirth, Address address, long telephoneNumber) : base(regNum,name, dateOfBirth, address, telephoneNumber)
        {
        }
        public Swimmer() : base() { }

        public void AddAsBestTime(PoolType poolType, EventDistance distance, Stroke stroke, TimeSpan swimTime)
        {
            string a = Convert.ToString(poolType) + Convert.ToString(distance) + Convert.ToString(stroke);
            if (eventInfo.Contains(a))
            {
                if (time[eventInfo.IndexOf(a)] > swimTime)
                {
                    time[eventInfo.IndexOf(a)] = swimTime;
                }
            }
            else
            {
                eventInfo.Add(a);
                time.Add(swimTime);
            }
        }
        public override string ToString()
        {
            

            if (Club == null && coach==null)
                return $"Name: {Name}\nDOB: {DateOfBirth}\nAddress:\n\t{Address.AddressLine}\n\t{Address.City}\n\t{Address.Province}\n\t{Address.PostalCode}\nPhone:{PhoneNumber}\nReg number: {RegNumber}\nClub: not assigned\nCoach:not assigned";
            else if (Club != null && coach == null)
                    return $"Name: {Name}\nDOB: {DateOfBirth}\nAddress:\n\t{Address.AddressLine}\n\t{Address.City}\n\t{Address.Province}\n\t{Address.PostalCode}\nPhone:{PhoneNumber}\nReg number: {RegNumber}\nClub: {Club.Name}\nCoach:not assigned";
                else if (Club == null && coach != null)
                    return $"Name: {Name}\nDOB: {DateOfBirth}\nAddress:\n\t{Address.AddressLine}\n\t{Address.City}\n\t{Address.Province}\n\t{Address.PostalCode}\nPhone:{PhoneNumber}\nReg number: {RegNumber}\nClub: not assigned\nCoach:{coach.Name}";
                else 
                    return $"Name: {Name}\nDOB: {DateOfBirth}\nAddress:\n\t{Address.AddressLine}\n\t{Address.City}\n\t{Address.Province}\n\t{Address.PostalCode}\nPhone:{PhoneNumber}\nReg number: {RegNumber}\nClub: {Club.Name}\nCoach:{coach.Name}";
        }

        public TimeSpan GetBestTime(PoolType poolType, Stroke stroke, EventDistance distance)
        {
            string a = Convert.ToString(poolType) + Convert.ToString(distance) + Convert.ToString(stroke);
            if (eventInfo.Contains(a))
            {
                return time[eventInfo.IndexOf(a)];
                
            }
            else
            {
                return new TimeSpan(0);
            }
        }
    }

}

