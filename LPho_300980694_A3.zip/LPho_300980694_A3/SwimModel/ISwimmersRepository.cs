﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwimModel
{
    public interface ISwimmersRepository
    {
        int Number
        {
            get;
        }
        void Add(Swimmer swimmer);
        Swimmer GetByRegNum(int swimmerNumber);
        void Load(string fileName,string input);
        void Save(string fileName,string input);
        // number
    }
}
