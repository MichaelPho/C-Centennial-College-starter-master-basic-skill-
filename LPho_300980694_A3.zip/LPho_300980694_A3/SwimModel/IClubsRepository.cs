﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwimModel
{
    public interface IClubsRepository
    {
        int Number
       {
            get;
        }
        void Add(Club club);
        Club GetClubByRegNum(int clubNumber);
        void Load(string fileName,string input);
        void Save(string fileName, string input);
    }
}
