﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SwimModel;
namespace SwimModelTest
{
    [TestClass]
    public class ClubTest
    {
        
        
        [TestMethod]
        [ExpectedException(typeof(Exception), "TheSameClubNumber")]
        public void RegistrantInClub_AssignedTheSameRegToClub_ExpectedToThrowException()
        {
            Registrant r1 = new Registrant();
            Club c1 = new Club();
            
            c1.AddSwimmer(r1);
            c1.AddSwimmer(r1);

        }
        [TestMethod]
        public void RegistrantInClub_AddRegistrantToClub_ExpectedToBeTheSame()
        {
            Club c1 = new Club();
            Address address = new Address("1 King St", "Toronto", "ON", "M2M 3M3");
            string name = "John Lee";
            long phoneNumber = 4162222560;
            DateTime dateOfBirth = new DateTime(1950, 12, 1);
            Registrant club2 = new Registrant(name, dateOfBirth, address, phoneNumber);
            c1.AddSwimmer(club2);
            Assert.AreEqual(c1.Swimmers[0].Name, name);
            Assert.AreEqual(c1.Swimmers[0].PhoneNumber, phoneNumber);
            Assert.AreEqual(c1.Swimmers[0].RegNumber, club2.RegNumber);
            Assert.AreEqual(c1.Swimmers[0].DateOfBirth, dateOfBirth);
            Assert.AreEqual(c1.Swimmers[0].Address, address);
        }
        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void AddReg_WhenAmountOfRegIsMaximum_ShouldThrowIndexOutOfRangeException()
        {
            Club club = new Club();
            for (int i = 0; i <= 101; i++)
                club.AddSwimmer(new Registrant());
        }
        [TestMethod]
        public void AssignInfoClub_AddDirectlyBySetToClub_ExpectedToBeAbleSet()
        {
            Club club = new Club();

            club.Address = new Address("1 King St", "Toronto", "ON", "M2M 3M3");
            club.Name = "John Lee";
            club.PhoneNumber = 4162222222;
            int num = 1;
            club.SwimmerAmount = num;

        }
        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void AddRegs_WhenAmountOfRegsIsMaximum_ShouldThrowIndexOutOfRangeException()
        {
            Club club = new Club();
            for (int i = 0; i <= 300; i++)
                club.AddSwimmer(new Registrant());
        }
        [TestMethod]
        public void SeeInfoClub_OpenDirectlyByGetToClub_ExpectedToBeTheSame()
        {

           
            Address address = new Address("1 King St", "Toronto", "ON", "M2M 3M3");
            string name = "John Lee";
            long phoneNumber = 4162222560;
            DateTime dateOfBirth = new DateTime(1950, 12, 1);

            int num = 0;
            
            Club club = new Club(name,address,phoneNumber);
            club.SwimmerAmount = num;
            string expected1 = club.Name;
            Address    expected2 = club.Address;
            long    expected3 = club.PhoneNumber;
           int     expected4 = club.SwimmerAmount;
           
            Assert.AreEqual( phoneNumber, expected3);
            Assert.AreEqual( num, expected4);
            Assert.AreEqual(name, expected1);
            Assert.AreEqual(address, expected2);

        }
        [TestMethod]
        public void GetInfoClub_OpenByGetInfoMethod_ExpectedToBeTheSame()
        {
            
            Address address = new Address("1 King St", "Toronto", "ON", "M2M 3M3");
            string name = "John Lee";
            long phoneNumber = 4162222560;
            DateTime dateOfBirth = new DateTime(1950, 12, 1);

            int num = 0;

            Club club = new Club(name, address, phoneNumber);
            club.SwimmerAmount = num;
            char[] b = phoneNumber.ToString().ToCharArray();
            Assert.AreEqual($"CLUB_ID is: {club.ClubNumber}\nBrand name is: {club.Name}\nAddress:\n\t{club.Address.AddressLine}\n\t{club.Address.City}\n\t{club.Address.Province}\n\t{club.Address.PostalCode}\nTelephone number: ({b[0]}{b[1]}{b[2]}) {b[3]}{b[4]}{b[5]} {b[6]}{b[7]}{b[8]}{b[9]}\nSwimmers:" ,club.ToString());
            Registrant registrant = new Registrant();
            registrant.Name = name;
            club.AddSwimmer(registrant);
            string listname= "\n\t-" + registrant.Name;
            Assert.AreEqual($"CLUB_ID is: {club.ClubNumber}\nBrand name is: {club.Name}\nAddress:\n\t{club.Address.AddressLine}\n\t{club.Address.City}\n\t{club.Address.Province}\n\t{club.Address.PostalCode}\nTelephone number: ({b[0]}{b[1]}{b[2]}) {b[3]}{b[4]}{b[5]} {b[6]}{b[7]}{b[8]}{b[9]}\nSwimmers:{listname}", club.ToString());

        }
       
    }
}
