﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SwimModel;
namespace SwimModelTest
{
    /// <summary>
    /// Summary description for UnitTest4
    /// </summary>
    [TestClass]
    public class EventTest
    {
       
        
        
        [TestMethod]
        [ExpectedException(typeof(Exception), "Swimmer is not in this event")]

        public void TimeSpanInEvent_AssignedTheTimeToSwimmerNotAttendedToEvent_ExpectedToThrowExceptionNotExist()
        {
            Swim information = new Swim(5, 6);
            Event event1 = new Event();
            Registrant r1 = new Registrant();

            event1.Info[0] = information;
            event1.EnterSwimmersTime(r1, "05:25.023");
            TimeSpan expect = new TimeSpan(0, 0, 5, 25, 23);
            Assert.AreEqual(expect, event1.Info[0].SwimTime);

        }

        [TestMethod]
        public void CheckInfoEvent_OpenDirectlyByUsingGetInfoMethod_ExpectedToBeTheSame()
        {

            
           
            Swim[] info = new Swim[3];

            Event @event2 = new Event(EventDistance._1500, Stroke.Butterfly);
           
            Swim expect5 = new Swim(new TimeSpan(0, 0, 0, 0, 0), 7, 4);
            info[1] = new Swim(3, 4);
            info[2] = new Swim();
            info[0] = new Swim(new TimeSpan(0, 0, 0, 0, 0), 7, 4);
           
            Stroke expectation6 = Stroke.Butterfly;
            EventDistance expectation7 = EventDistance._1500;
            Assert.AreEqual($"Code is :{expectation6}\nDistance is :{(int)expectation7}/meters", @event2.ToString());
            

        }
       
    }
}
