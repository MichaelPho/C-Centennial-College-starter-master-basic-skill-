﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SwimModel;
namespace SwimModelTest
{
    /// <summary>
    /// Summary description for UnitTest3
    /// </summary>
    [TestClass]
    public class SwimMeetTest
    {
        [TestMethod]
        
        public void PoolType_AssignedPoolTypeToEventAlreadyHadPoolType_ExpectedNotToChangeAfterAssigned()
        {
            SwimMeet _swimMeet = new SwimMeet();
            _swimMeet.PoolType = PoolType.SCM;
            _swimMeet.PoolType = PoolType.SCY;
            Assert.AreEqual(PoolType.SCM, _swimMeet.PoolType);
        }
        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void RegistrantInEvent_AssignedTheSameRegToEvent_ExpectedToThrowException()
        {
            SwimMeet sm1 = new SwimMeet();
            

            for (int i = 0; i < 300; i++)
            {
                sm1.AddEvent(new Event());
            }

        }
        [TestMethod]
        public void GetAmount_GetAmountAfterUsingAddMethod_ExpectedToBeTheSame()
        {
            SwimMeet _swimMeet = new SwimMeet();
            _swimMeet.AddEvent(new Event());
            _swimMeet.AddEvent(new Event());
            _swimMeet.AddEvent(new Event());
            _swimMeet.AddEvent(new Event());
            int expected = 4;
            Assert.AreEqual(expected, _swimMeet.EventAmount);
        }
    }
}
