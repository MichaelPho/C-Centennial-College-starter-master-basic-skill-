﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SwimModel;
namespace SwimModelTest
{
    /// <summary>
    /// Summary description for UnitTest2
    /// </summary>
    [TestClass]
    public class SwimTest
    {

        [TestMethod]
        public void TakeInformationSwim_OpenByusingGetInfoMethod_ExpectedToBeTheSame()
        {
            int heat = 9;
            int lane = 2;
            TimeSpan swimTime = new TimeSpan(0, 0, 0, 0, 0);
            TimeSpan swimTime2 = new TimeSpan(3, 5, 2, 23, 15);
            Swim s1 = new Swim();//default constructor

            Swim s2 = new Swim(heat,lane);//Constructor have lane and heat;
            Swim s3 = new Swim(new TimeSpan(3, 5, 2, 23, 15), heat, lane);// full Constructor
           

            Assert.AreEqual($"Time Swimming is:{swimTime.Minutes}:{swimTime.Seconds}.{swimTime.Milliseconds}\nHeat number is :0\nNumber of Lane is: 0", s1.GetInfo());

            Assert.AreEqual($"Time Swimming is:{swimTime.Minutes}:{swimTime.Seconds}.{swimTime.Milliseconds}\nHeat number is :{heat}\nNumber of Lane is: {lane}", s2.GetInfo());

            Assert.AreEqual($"Time Swimming is:{swimTime2.Minutes}:{swimTime2.Seconds}.{swimTime2.Milliseconds}\nHeat number is :{heat}\nNumber of Lane is: {lane}", s3.GetInfo());
        }
        [TestMethod]
        public void TakeInformationSwim2_OpenByusingGetAccessor_ExpectedToBeTheSame()
        {
            int heat = 9;
            int lane = 2;
            TimeSpan swimTime = new TimeSpan(0, 0, 0, 0, 0);
            TimeSpan swimTime2 = new TimeSpan(3, 5, 2, 23, 15);
            Swim s1 = new Swim();//default constructor

            Swim s2 = new Swim(heat, lane);//Constructor have lane and heat;
            Swim s3 = new Swim(new TimeSpan(3, 5, 2, 23, 15), heat, lane);// full Constructor
            Assert.AreEqual(swimTime, s1.SwimTime);
            Assert.AreEqual(heat, s2.Heat);
            Assert.AreEqual(lane, s2.Lane);

            }

    }
}
