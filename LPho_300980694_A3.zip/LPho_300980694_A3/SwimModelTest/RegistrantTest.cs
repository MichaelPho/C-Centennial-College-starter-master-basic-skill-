﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SwimModel;
namespace SwimModelTest
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class RegistrantTest
    {
        [TestMethod]
        
        public void AssignInfoReg_AddDirectlyBySetToRegistrant_ExpectedToBeAbleSet()
        {
            Registrant registrant = new Registrant();

            registrant.Address = new Address("1 King St", "Toronto", "ON", "M2M 3M3");
            registrant.Name = "John Lee";
            registrant.PhoneNumber = 4162222222;
            
            

        }
        [TestMethod]
        public void SeeInfoRegistrant_OpenDirectlyByGetToRegistrant_ExpectedToBeTheSame()
        {

            Registrant registrant1 = new Registrant();
            Registrant registrant2 = new Registrant();
            Address address = new Address("1 King St", "Toronto", "ON", "M2M 3M3");
            string name = "John Lee";
            long phoneNumber = 4162222560;
            DateTime dateOfBirth = new DateTime(1950, 12, 1);
            

            Registrant Registrant = new Registrant(name,dateOfBirth, address, phoneNumber);
            
            string expected1 = Registrant.Name;
            Address expected2 = Registrant.Address;
            long expected3 = Registrant.PhoneNumber;
            Assert.AreEqual(name, expected1);
            Assert.AreEqual(address, expected2);
            Assert.AreEqual(phoneNumber, expected3);


            ReferenceEquals(registrant1, registrant2);

        }
        
        [TestMethod]
        public void GetInfoClub_OpenByGetInfoMethod_ExpectedToBeTheSame()
        {

            Address address = new Address("1 King St", "Toronto", "ON", "M2M 3M3");
            string name = "John Lee";
            long phoneNumber = 4162222560;
            DateTime dateOfBirth = new DateTime(1950, 12, 1);

            int num = 0;

            Club club = new Club(name, address, phoneNumber);
            Registrant registrant = new Registrant();
            Registrant registrant2 = new Registrant(name,dateOfBirth,address,phoneNumber);
            
            club.SwimmerAmount = num;
            club.AddSwimmer(registrant2);
            
            Assert.AreEqual($"Name: {name}\nDOB: {dateOfBirth}\nAddress:\n\t{address.AddressLine}\n\t{address.City}\n\t{address.Province}\n\t{address.PostalCode}\nPhone:{phoneNumber}\nReg number: {registrant2.RegNumber}\nClub: {club.Name}", registrant2.ToString());
            Assert.AreEqual($"Name: \nDOB: {registrant.DateOfBirth}\nAddress:\n\t\n\t\n\t\n\t\nPhone:{registrant.PhoneNumber}\nReg number: {registrant.RegNumber}\nClub: not assigned", registrant.ToString());

        }

    }
}
