﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SwimModel;
using System.IO;

namespace SwimModelTest
{
    /// <summary>
    /// Summary description for UnitTest5
    /// </summary>
    [TestClass]
    public class ClubsManagerTest
    {
       

        

        [TestMethod]
        [ExpectedException(typeof(FileNotFoundException), "File is not there")]
        public void ImportClubs_FileNotFound_ThowEX()
        {
            ClubsManager newClubsManager = new ClubsManager();

            newClubsManager.Load("Cefewfs.txt", ",");
        }

        [TestMethod]
        public void ImportClubs2_FileFound()
        {
            ClubsManager newClubsManager = new ClubsManager();

            newClubsManager.Load("Clubs.txt", ",");
            int actual = 4;
            Assert.AreEqual(newClubsManager.Number, actual);
        }

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void GetClub_UsingTheCheckClubByRegNumMethod_ExpectedToThrowException() {
            ClubsManager newClubsManager = new ClubsManager();

            newClubsManager.Load("Clubs.txt", ",");
            newClubsManager.GetClubByRegNum(92).ToString();
            
        }

       

        

        [TestMethod]
        public void FindClub_ReturningTheChosenClubInfo_GetClubByRegNum()
        {
            ClubsManager ClubMng = new ClubsManager();
            Club club1 = new Club();

            club1.PhoneNumber = 4164444444;
            club1.Name = "NYAC";

            Club club2 = new Club("CCAC", new Address("35 River St", "Toronto", "ON", "M2M 5M5"), 4165555555);

            ClubMng.Add(club1);
            ClubMng.Add(club2);

            Club actual = ClubMng.GetClubByRegNum(club2.ClubNumber);
            Club expect = club2;
            ReferenceEquals(actual, expect);
        }

        
    }
}
