﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace LPho_300980694_A2
{
    [Serializable]
    public enum Stroke
    {
        Butterfly = 1, Backstroke, Breaststroke, Freestyle,
        individualmedley
    };
    [Serializable]
    public enum EventDistance { _50 = 50, _100 = 100, _200 = 200, _400 = 400, _800 = 800, _1500 = 1500 };
    [Serializable]
    public enum PoolType { SCM, SCY, LCM };
    [Serializable]
    public struct Address
    {
        public string AddressLine;
        public string City;
        public string Province;
        public string PostalCode;
        public Address(string addressLineIn, string cityIn, string provinceIn, string postalCodeIn)
        {
            AddressLine = addressLineIn;
            City = cityIn;
            Province = provinceIn;
            PostalCode = postalCodeIn;
        }
    };
    [Serializable]
     class Club
    {
        const int regLimit=20;
        Registrant[] swimmers = new Registrant[20];
        int swimmerAmount = 0;
        int clubNumber = 0;
        string name;
        long telephoneNumber;
        Address address = new Address();
        public Registrant[] Swimmers { get { return swimmers; } }
        
        public int SwimmerAmount
        {
            get { return swimmerAmount;
            }
            set { swimmerAmount = value; }
        }

        public int ClubNumber
        {
            private set
            {
                clubNumber = value;
            }
            get
            {
                return clubNumber;
            }
        }

        public string Name
        {
            set
            {
                name = value;
            }
            get
            {
                return name;
            }
        }

        public Address Address
        {
            set
            {
                address = value;
            }
            get
            {
                return address;
            }
        }
        public long PhoneNumber
        {
            set
            {
                if (value.ToString().Length != 10)
                {
                    Console.WriteLine("this number is not approriate");
                    telephoneNumber = 0;

                }
                else
                    telephoneNumber = value;
            }
            get
            {
                return telephoneNumber;
            }
        }
        public Club(string name, Address address, long telephoneNumber)
        {

            

            ClubNumber = ++Registrant.RegIdNumber;
            Name = name;

            Address = address;
            PhoneNumber = telephoneNumber;
        }
        public Club()
        {
            Address = new Address("", "", "", "");
            this.swimmerAmount = 0;
            


            ClubNumber = ++Registrant.RegIdNumber;
            Name ="";
            this.telephoneNumber = 0;
            

        }
        public Club(int regNum, string name, long phone, string street="",string city="",string province="" , string postalcode="")
        {
            Address = new Address(street,city, province,postalcode);
            this.swimmerAmount = 0;
            clubNumber = regNum;
            Name = name;
            PhoneNumber = phone;
            
        }
        public void AddSwimmer(Registrant swimmer)
        {

            if (SwimmerAmount < regLimit)
            {
                for (int i = 0; i < Swimmers.Length; i++)
                {
                    if (Swimmers[i] == null)
                    {
                        Swimmers[i] = swimmer;
                        swimmer.Club = this;
                        this.swimmerAmount += 1;
                        break;
                    }
                    else if (Swimmers[i].RegNumber == swimmer.RegNumber || swimmer.Club!= null)
                       throw new Exception($"Swimmer already Assigned to {swimmer.Club.Name}");
                }
            }
            else { throw new Exception("over limit"); }
        
        }
        public string GetInfo()
        {

            
                string a = PhoneNumber.ToString();
                char[] b = a.ToCharArray();
                string listname = "";

                for (int i = 0; i < SwimmerAmount; i++)
                {
                    if (Swimmers[i] != null)
                    {
                        listname = listname + "\n\t-" + Swimmers[i].Name;
                    }

                }
            if (PhoneNumber == 0)
                return $"CLUB_ID is: {ClubNumber}\nBrand name is: {Name}\nAddress:\n\t{Address.AddressLine}\n\t{Address.City}\n\t{Address.Province}\n\t{Address.PostalCode}\nTelephone number: {PhoneNumber}\nSwimmers:{listname}";

            return $"CLUB_ID is: {ClubNumber}\nBrand name is: {Name}\nAddress:\n\t{Address.AddressLine}\n\t{Address.City}\n\t{Address.Province}\n\t{Address.PostalCode}\nTelephone number: ({b[0]}{b[1]}{b[2]}) {b[3]}{b[4]}{b[5]} {b[6]}{b[7]}{b[8]}{b[9]}\nSwimmers:{listname}";
            
            
            
                }
        static public bool CheckNum(string input)
        {

            int test;
            if (int.TryParse(input, out test))
            {
                if (int.Parse(input) < 0)
                {
                    return false;
                }
                return true;
            }
            return false;
        }

        static public string Formating(string text)
        {
            return UppercaseFirstEach(Regex.Replace(text, " {2,}", " ").Trim());
        }

        static public string UppercaseFirstEach(string s)
        {

            char[] a = s.ToLower().ToCharArray();

            for (int i = 0; i < a.Length; i++)
            {
                if (i == 0 || a[i - 1] == ' ')
                    a[i] = char.ToUpper(a[i]);
            }

            return new string(a);
        }
        
        
    }
}

