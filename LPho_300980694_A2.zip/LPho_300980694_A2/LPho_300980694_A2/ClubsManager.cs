﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace LPho_300980694_A2
{
    class ClubsManager
    {
        int numberOfClubs = 0;
        public int NumberOfClubs { get { return numberOfClubs; } private set { numberOfClubs = value; } }
        int limitClubs = 100;
        Club[] clubs = new Club[100];
        public Club[] Clubs { get { return clubs; } }
        public ClubsManager() {
            clubs = new Club[100];
        }
        public void Add(Club club) {
            bool check = false;
            if (numberOfClubs > limitClubs)
                Console.WriteLine("over limit");
            else
            {
                for (int i = 0; i <= NumberOfClubs; i++)
                {
                    if (Clubs[i] != null)
                    {
                        if (Clubs[i].ClubNumber == club.ClubNumber && Clubs[i] != null)
                        {
                            Console.WriteLine("already added in this club");
                            break;
                        }
                        
                    }
                    else
                    {
                        clubs[i] = club;
                        check = true;
                        break;
                    }
                }
                if (check) this.numberOfClubs++;
            }
        }
        public Club GetClubByRegNum(int clubNumber)
        {
            
                for (int i = 0; i < NumberOfClubs; i++)
                {
                    if (Clubs[i].ClubNumber == clubNumber)
                    {
                        return Clubs[i];
                    }
                    else if (Clubs[i] == null)
                    {
                        return null;
                    }
                }
                return null;
            
        }
        public void LoadClubs(string fileName, string input)
        {
            char delimeter = Convert.ToChar(input);
            Club[] Club = new Club[10];
            
            string record;
            string[] field;
            FileStream fileIn = null;
            StreamReader reader = null;
            try
            {
                fileIn = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                reader = new StreamReader(fileIn);


                long test;
                int test2;
                record = reader.ReadLine();
                while (record != null)
                {
                    field = record.Split(delimeter);

                    try
                    {

                        if (!int.TryParse(field[0], out test2))
                            throw new Exception($"Invalid club record Club number is not valid:\n\t {record}");
                        if (!long.TryParse(field[6], out test))
                            throw new Exception($"Invalid club record. Phone number wrong format:\n\t {record}");
                        for (int i = 0; i < numberOfClubs; i++)
                        {
                            if (GetClubByRegNum(int.Parse(field[0])) != null )
                            {
                                throw new Exception($"Invalid club record. Club with the registration number already exists: \n\t {record}");
                            }
                        }
                        Add(new Club(int.Parse(field[0]), field[1], long.Parse(field[6]), field[2], field[3], field[4], field[5]));

                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);

                    }
                    finally
                    {
                        record = reader.ReadLine();
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
                if (fileIn != null)
                {
                    fileIn.Close();
                }
            }
            Array.Resize(ref clubs, numberOfClubs);
            
        }
        public void Save(string fileName)
        {
            BinaryFormatter binFormatter = new BinaryFormatter();
            FileStream fileOut = new FileStream(fileName, FileMode.Create, FileAccess.Write);
            try
            {
                binFormatter.Serialize(fileOut, clubs);
            }
            catch (Exception e)
            {

                Console.WriteLine(e.Message);
            }
            finally
            {
                if (fileOut != null)
                {
                    fileOut.Close();
                }
                
            }
        }

        public void Load(string fileName)
        {

            BinaryFormatter binaryFormatter = null;
            FileStream fileIn = null;

            try
            {
                binaryFormatter = new BinaryFormatter();
                fileIn = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                try
                {
                    clubs = (Club[])binaryFormatter.Deserialize(fileIn);
                }
                catch (ArgumentOutOfRangeException e)
                {
                    throw new Exception("overange\n" + e.Message);

                }
                foreach (var club in clubs)
                {
                    if (club != null)
                    {
                        numberOfClubs++;
                    }
                }

            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
            finally {
                if (fileIn!=null)
                    fileIn.Close();
            }
        }
        
    }
}
