﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LPho_300980694_A2
{
    [Serializable]
     class Event
    {
        
        EventDistance distance;
        Stroke stroke;
        SwimMeet swimMeet;
        const int regLimit = 100;
        
        Registrant[] swimmers = new Registrant[100];
        int amountOfSwimmer;
        Swim [] info =new Swim[100];
        public Swim [] Info { get { return info; } set { info = value; } }
        public int AmountOfSwimmers { get { return amountOfSwimmer; } }
        
        public SwimMeet SwimMeet { get { return swimMeet; } set { swimMeet = value; } }
        public Registrant[] Swimmers { get { return swimmers; } }
        public EventDistance Distance
        {
            set { distance = value; }
            get { return distance; }
        }
        public Stroke Stroke
        {
            set { stroke = value; }
            get { return stroke; }
        }
        public Event( EventDistance distance, Stroke stroke)
        {
            Stroke = stroke;
            Distance = distance;
        }
        public Event() {
            Stroke = 0;
            Distance = 0;
        }
        
        public string GetInfo()
        {
            return $"Code is :{Stroke}\nDistance is :{(int)Distance}/meters";
        }

        public void EnterSwimmersTime(Registrant swimmer1, string v)
        {
            TimeSpan SwimTime= new TimeSpan(0,0,0,0);
            try
            {
                SwimTime = TimeSpan.Parse($"00:{v}");
            }
            catch(Exception e) {
               throw new Exception("Time input is not correct!!!!");
            }

            bool checking = false;

            for (int i = 0; i < Swimmers.Length; i++)
            {
                if (Swimmers[i] != null)
                {
                    if (Swimmers[i].RegNumber == swimmer1.RegNumber)
                    {
                        Info[i].SwimTime = SwimTime;
                        checking = true;
                        break;
                    }
                }
            }
            if (checking == false)
            {
                throw new Exception($"Swimmer {swimmer1.Name} has not entered event");
            }
           
        }

        public void Seed(int a, int @noOfHeat,int @noOfLane) {

            
            for (int i = 0; i < Swimmers.Length; i++)
            {
                if (Swimmers[i].RegNumber == a)
                {
                    Info[i]= new Swim(@noOfHeat,@noOfLane);
                    break;
                }
            }
        }

        public void AddSwimmer(Registrant swimmer)
        {
            if (AmountOfSwimmers >= 0 && AmountOfSwimmers < regLimit)
            {
                if (AmountOfSwimmers == 0)
                {
                    this.swimmers[this.amountOfSwimmer++] = swimmer;
                    swimmer.AddEvent(this);
                }
                else
                {
                    bool check = true;
                    for (int i = 0; i < this.amountOfSwimmer; i++)
                    {
                        if (this.swimmers[i].RegNumber == swimmer.RegNumber)
                            check = false;
                    }
                    if (!check)
                    {
                        throw new Exception($"Swimmer {swimmer.Name},{swimmer.RegNumber} is already entered");
                    }
                    else
                    {
                        if(swimmer.AddEvent(this))
                        this.swimmers[this.amountOfSwimmer++] = swimmer;
                        else
                        throw  new Exception("It's over range of the Amount");
                    }

                }
            }
            else
               throw new Exception("It's over range of the Amount");
        }
    }
}
