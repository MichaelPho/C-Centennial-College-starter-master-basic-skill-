﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LPho_300980694_A2
{
    [Serializable]
    class Registrant
    {

        Club club;
        const int eventLimit=50;
        public static int RegIdNumber = 0;
        int regNumber;
        string name;
        DateTime dateOfBirth;
        long telephoneNumber;
        Address address = new Address();

        Event[] @event = new Event[50];
        int amountOfEvent = 0;
        public int AmountOfEvent { get { return amountOfEvent; } }
        public Event[] @Event { get { return @event; } private set { @event = value;  } }

        public Club Club
        {
            get { return club; }
            set
            {
                if ((club != null))
                {
                    throw new Exception($"{this.name} already assigned to {Club.Name} club");
                }
                else
                {
                    club = value;
                    club.Swimmers[club.SwimmerAmount++] = this;

                }
                }
            }

        
        
    
    
        
        public int RegNumber
        {
            private set
            {
                regNumber = value;
            }
            get
            {
                return regNumber;
            }
        }
        public string Name
        {
            set
            {
                
                name = Club.Formating(value);
            }
            get
            {
                return name;
            }
        }
        public DateTime DateOfBirth
        {
            set { dateOfBirth = value; }
            get { return dateOfBirth; }
        }
        public Address Address
        {
            set
            { address = value; }
            get
            { return address; }
        }


        public long PhoneNumber
        {
            set
            {
                if (value.ToString().Length != 10)
                {
                    Console.WriteLine("this number is not approriate");
                    telephoneNumber = 0;
                }
                else
                    telephoneNumber = value;
            }
            get
            {
                return telephoneNumber;
            }
        }
        public Registrant(string name, DateTime dateOfBirth, Address address, long telephoneNumber)
        {
            
            RegNumber = ++RegIdNumber;
            Name = name;

            if (dateOfBirth >= DateTime.Now)
            {
                DateOfBirth = new DateTime(0001, 1, 1);
            }
            else
                DateOfBirth = dateOfBirth;
            PhoneNumber = telephoneNumber;
            Address = address;
        }
        public bool AddEvent(Event @event) {
            if (AmountOfEvent <= eventLimit)
            {
                this.@event[this.amountOfEvent++] = @event;
                return true;
            }
            else
            { 
                return false;
            }
        }

        public Registrant() {
            RegNumber = ++RegIdNumber;
            Address = new Address("","","","");
            Name = "";
            this.telephoneNumber = 0; ;
            
            DateOfBirth = new DateTime(0001,1,1);
            
        }

        
        

        public string GetInfo()
        {
            
           if (Club==null)
                return $"Name: {Name}\nDOB: {DateOfBirth}\nAddress:\n\t{Address.AddressLine}\n\t{Address.City}\n\t{Address.Province}\n\t{Address.PostalCode}\nPhone:{PhoneNumber}\nReg number: {RegNumber}\nClub: not assigned";
            else
                return $"Name: {Name}\nDOB: {DateOfBirth}\nAddress:\n\t{Address.AddressLine}\n\t{Address.City}\n\t{Address.Province}\n\t{Address.PostalCode}\nPhone:{PhoneNumber}\nReg number: {RegNumber}\nClub: {Club.Name}";

        }
    }
}
