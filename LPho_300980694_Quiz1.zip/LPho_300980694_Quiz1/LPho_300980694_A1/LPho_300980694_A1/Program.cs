﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LPho_300980694_A1
{
    class Program
    {
        static void Main(string[] args)
        {
            Display();
            Console.ReadKey();
        }
        static void Display()
        {
            Start: Console.Clear();
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Green;
            int choice = 0;

            Console.WriteLine("\t\t\t*****ASSGINMENT 1 (Centennial College X Programming 2)*****");
            Console.WriteLine();
            Console.WriteLine("  |||             ||| ========  ||	    ========  ==========   ||||||     ||||||  ========");
            Console.WriteLine("   |||    ||||   |||  ===       ||	    ==	      ==      ==   ||| |||   ||| |||  ===");
            Console.WriteLine("    |||  |||||| |||   =======   ||	    ==        ==      ==   |||  ||| |||  |||  =======");
            Console.WriteLine("     ||||||  |||||    ===       ||	    ==        ==      ==   |||   |||||   |||  ===");
            Console.WriteLine("      ||||    |||     ========  ||======    ========  ==========   |||    |||    |||  ========");
            Console.WriteLine(" --------------------------------------------------------------------------------------------");
            Console.WriteLine("\t======================================================================");
            Console.WriteLine("\t=             !!!!CHAPTER EXAMPLE 1~7 (Except 3)!!!!                 =");
            Console.WriteLine("\t=                       Choose Number                                =");
            Console.WriteLine("\t=                 -> 1. Chapter 1                                    =");
            Console.WriteLine("\t=                 -> 2. Chapter 2                                    =");
            Console.WriteLine("\t=                 -> 3. X                                            =");
            Console.WriteLine("\t=                 -> 4. Chapter 4                                    =");
            Console.WriteLine("\t=                 -> 5. Chapter 5                                    =");
            Console.WriteLine("\t=                 -> 6. Chapter 6                                    =");
            Console.WriteLine("\t=                 -> 7. Chapter 7                                    =");
            Console.WriteLine("\t=                 -> 8. Exit!!!                                      =");
            Console.WriteLine("\t=                                                                    =");
            Console.WriteLine("\t======================================================================");
            Console.WriteLine("\t\tPlease enter your choice");
            Console.Write("\t\t    choice:"); // this is the chapter choice option

            bool checkNum = false;
            while (checkNum == false)
            {
                checkNum = int.TryParse(Console.ReadLine(), out choice);//check if input is integer
                if (choice <= 0 || choice > 8) //checking if the choice in option or not
                {
                    Console.WriteLine("\t\tPlease try again");
                    Console.WriteLine("----------- Press any key to continue   ----------- ");

                    checkNum = false;
                    Console.Write("\t\t    choice:");
                }


            }

            if (choice == 1)
            {
                chapterOne();
            }
            else if (choice == 2)
            {
                chapterTwo();
            }
            else if (choice == 4)
            {
                chapterFour();
            }
            else if (choice == 5)
            {
                chapterFive();
            }
            else if (choice == 6)
            {
                chapterSix();
            }
            else if (choice == 7)
            {
                chapterSeven();
            }
            else if (choice == 8)
            {
                goto Start1;
            }

            Console.WriteLine("\t\tDo you want to do more?(Y/N)");
            string tryMore = Convert.ToString(Console.ReadLine());
            if (tryMore == "Y" || tryMore == "y" || tryMore == "yes")
            {
                goto Start;
            }

            Start1:
            Console.WriteLine("Thank You HAVE A GOOD DAY!!!!!!\n\n\t\t\t\t\t P/s: Thanh Lam\n      \t\t\t\t\t #300980694");

        }
        static void chapterOne()
        {
            Console.Clear();
            displayWithBorder("Chapter 1");
            Console.WriteLine("Please Choose Size For Glass of Wine (M/L)?");
            string size = Console.ReadLine();
            if (size.ToUpper() == "M")
            {
                Console.WriteLine("XXXXXXXXXXXXX");
                Console.WriteLine(" X         X");
                Console.WriteLine("  X       X");
                Console.WriteLine("   XXXXXXX");
                Console.WriteLine("      X");
                Console.WriteLine("      X");
                Console.WriteLine("    XXXXX");
            }
            else if (size.ToUpper() == "L")
            {
                Console.WriteLine("XXXXXXXXXXXXXXXXXXX");
                Console.WriteLine(" X               X");
                Console.WriteLine("  X             X");
                Console.WriteLine("   XXXXXXXXXXXXX");
                Console.WriteLine("         X");
                Console.WriteLine("         X");
                Console.WriteLine("         X");
                Console.WriteLine("         X");
                Console.WriteLine("     XXXXXXXXX");
            }
            else
            { Console.WriteLine("We dont have that size for you"); }
        }
        static void displayWithBorder(string input)
        {

            Console.WriteLine("                    CCCCC   #  #");
            Console.WriteLine("                    C     ########");
            Console.WriteLine("                    C       #  #");
            Console.WriteLine("                    C     ########");
            Console.WriteLine("                    CCCCC   #  #");

            Console.WriteLine("======================================================================");
            Console.WriteLine("=\t\t\t{0}\t\t\t\t     {1}", input, "=");
            Console.WriteLine("=                                                                    =");
            Console.WriteLine("=                                                                    =");
            Console.WriteLine("======================================================================");
            Console.WriteLine("----------------------------------------------------------------------");
        }
        static void chapterTwo()
        {
            displayWithBorder("Chapter 2");
            const double ratingRasie = 0.04;
            float[] salary = { 5000, 4300, 2000 };
            string[] employeeName = { "Jack", "Rosie", "Grant" };
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine($"the salary of {employeeName[i]} in next year will be raise from {salary[i].ToString("C")} to {(salary[i] + (salary[i] * ratingRasie)).ToString("C")}");
            }
            Console.WriteLine();
        }
        static void chapterFour()
        {
            Console.Clear();
            displayWithBorder("Chapter 4");
            Console.WriteLine();
            Console.Write("\t\t    Guessing number 1 to 10 (3 trials):"); // this is the chapter choice option
            Random ranNumberGenerator = new Random();
            int randomNumber = ranNumberGenerator.Next(1, 11);
            for (int i = 0; i < 3; i++)
            {

                int guess = Convert.ToInt32(Console.ReadLine());
                if (guess == randomNumber)
                {
                    Console.WriteLine("\t\tCorrect!!!!");
                    break;
                }
                else if (guess < randomNumber)
                {
                    Console.WriteLine("\t\tChoose higher!!!!");
                }
                else if (guess > randomNumber)
                {
                    Console.WriteLine("\t\tChoose Lower!!!!");
                }
                Console.WriteLine("\t\tyou have " + (2 - i) + " trial left");
                Console.Write("\t\t");
            }

        }
        static void chapterFive()
        {
            int num = 0;
            Console.Clear();
            displayWithBorder("Chapter 5");
            Console.WriteLine("======================================================================");
            Console.WriteLine("=                       ODD NUMBER FROM 1 - 100                      =");
            Console.WriteLine("=                                                                    =");
            Console.WriteLine("=                 ||              ||             ||                  =");
            Console.WriteLine("=                 ||              ||             ||                  =");
            Console.WriteLine("=               | || |          | || |         | || |                =");
            Console.WriteLine("=                ||||            ||||           ||||                 =");
            Console.WriteLine("=                 ||              ||             ||                  =");
            Console.WriteLine("=                                                                    =");
            Console.WriteLine("======================================================================");
            for (int i = 0; i < 100; i++)
            {
                if (i % 2 != 0)
                {
                    Console.Write(i + "\t|");
                }
                if (i % 10 == 0)
                    Console.WriteLine();
            }
        }
        static void chapterSix()
        {

            displayWithBorder("Chapter 6");
            Console.WriteLine("======================================================================");
            Console.WriteLine("=              How Long Will You Travel(kilometer)                   =");
            Console.WriteLine("=                                                                    =");
            Console.WriteLine("=                 1. 0 - 99                                          =");
            Console.WriteLine("=                 2. 100 - 299                                       =");
            Console.WriteLine("=                 3. 300 - 499                                       =");
            Console.WriteLine("=                 4. 500 and Farther                                 =");
            Console.WriteLine("=                 5. ENTER AMOUNT                                    =");
            Console.WriteLine("=                                                                    =");
            Console.WriteLine("======================================================================");
            Console.WriteLine("\t\tPlease enter your choice");
            Console.Write("\t\t    choice:");
            int choice = 0;
            bool checkNum = false;
            while (checkNum == false)
            {
                checkNum = int.TryParse(Console.ReadLine(), out choice);//check if input is integer
                if (choice <= 0 || choice > 8) //checking if the choice in option or not
                {
                    Console.WriteLine("\t\tPlease try again");
                    Console.WriteLine("----------- Press any key to continue   ----------- ");

                    checkNum = false;
                    Console.Write("\t\t    choice:");
                }
            }
            if (choice == 5)
            {
                Console.WriteLine("\t\tamount: ");
                float num;
                num = float.Parse(Console.ReadLine());
                if (num < 100)
                    choice = 1;
                else if (num >= 100 && num < 299)
                {
                    choice = 2;
                }
                else if (num >= 300 && num < 499)
                    choice = 3;
                else if (num >= 500)
                    choice = 4;
            }
            if (choice == 1)
            {
                Console.WriteLine("\t\tit cost: 25$");
            }
            else if (choice == 2)
            {
                Console.WriteLine("\t\tit cost: 40$");
            }
            else if (choice == 3)
            {
                Console.WriteLine("\t\tit cost: 55$");
            }
            else
            {
                Console.WriteLine("\t\tit cost: 70$");
            }


        }
        static string SubChapter7(double gpa, string type)
        {
            if ((type == "1" || type == "3" || type == "2") && gpa <3.0)
            {
                return "Reject!!!";
            }
            else if (type == "5")
            {
                Console.WriteLine("\t\tamount: ");
                float num;
                num = float.Parse(Console.ReadLine());
                if (num < 60)
                    type = "3";
                else if (num >= 60 && num < 80)
                {
                    if (gpa < 3.0)
                        return "Reject!!!";
                    else if (gpa >= 3.0)
                    { return "PASS!!!"; }
                }
                else if (num >= 80)
                    type = "4";
            }
            
            else if (type == "4")
            { Console.WriteLine("PASS!!!"); }
           
                return "PASS";
        }
        static void chapterSeven()
        {
            Console.WriteLine("======================================================================");
            Console.WriteLine("=                    How was your GPA                                =");
            Console.WriteLine("=                                                                    =");
            Console.WriteLine("=                 1. below 35                                        =");
            Console.WriteLine("=                 2. 35-50                                           =");
            Console.WriteLine("=                 3. 50-59                                           =");
            Console.WriteLine("=                 4. 80+                                             =");
            Console.WriteLine("=                 5. ENTER AMOUNT                                    =");
            Console.WriteLine("=                                                                    =");
            Console.WriteLine("======================================================================");
            Console.WriteLine("\t\tPlease enter your choice");
            Console.Write("\t\t    choice:");
            string type = Convert.ToString(Console.ReadLine());
            Console.Write("what is your GPA:");
            double gpa = Convert.ToDouble(Console.ReadLine());
            while (gpa < 0 || gpa > 4.5)
            {
                Console.Write("that is not right:");
                gpa = Convert.ToDouble(Console.ReadLine());
            }
            Console.WriteLine(SubChapter7(gpa, type));
            

        }
        
    }
}



